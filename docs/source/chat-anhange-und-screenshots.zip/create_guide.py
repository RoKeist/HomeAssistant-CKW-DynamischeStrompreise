from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.section import WD_SECTION

out='/workspace/scratch/117c8c48daf4/CKW_Dynamischer_Tarif_Home_Assistant_Anleitung.docx'
doc=Document()
sec=doc.sections[0]
sec.top_margin=Inches(.65); sec.bottom_margin=Inches(.65); sec.left_margin=Inches(.78); sec.right_margin=Inches(.78)
styles=doc.styles
styles['Normal'].font.name='Aptos'; styles['Normal'].font.size=Pt(10)
styles['Normal'].font.color.rgb=RGBColor(40,48,56)
for sname,size,color in [('Title',27,'17324D'),('Heading 1',18,'17324D'),('Heading 2',13,'087E8B'),('Heading 3',11,'17324D')]:
    s=styles[sname]; s.font.name='Aptos Display'; s.font.size=Pt(size); s.font.bold=True; s.font.color.rgb=RGBColor.from_string(color)
    s.paragraph_format.space_before=Pt(12 if sname!='Title' else 0); s.paragraph_format.space_after=Pt(5)

# header/footer
header=sec.header.paragraphs[0]
header.text='HOME ASSISTANT  /  CKW DYNAMISCHER TARIF'
header.style='Caption'; header.runs[0].font.color.rgb=RGBColor(8,126,139); header.runs[0].font.bold=True
footer=sec.footer.paragraphs[0]; footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=footer.add_run('Schritt-für-Schritt-Anleitung  •  Stand 17.11.2026'); r.font.size=Pt(8); r.font.color.rgb=RGBColor(100,110,120)

def p(text='', style=None): return doc.add_paragraph(text, style)
def bullet(text): return doc.add_paragraph(text, style='List Bullet')
step_no = 0
def reset_steps():
    global step_no
    step_no = 0
def numbered(text):
    global step_no
    step_no += 1
    para = doc.add_paragraph()
    para.paragraph_format.left_indent = Inches(.28)
    para.paragraph_format.first_line_indent = Inches(-.28)
    para.add_run(f'{step_no}. ').bold = True
    para.add_run(text)
    return para
def code(text):
    para=doc.add_paragraph()
    para.paragraph_format.left_indent=Inches(.16); para.paragraph_format.right_indent=Inches(.08)
    para.paragraph_format.space_before=Pt(2); para.paragraph_format.space_after=Pt(7)
    para.paragraph_format.keep_together=True
    pp=para._p.get_or_add_pPr(); shd=OxmlElement('w:shd'); shd.set(qn('w:fill'),'F1F5F8'); pp.append(shd)
    for i,line in enumerate(text.strip('\n').split('\n')):
        if i: para.add_run().add_break()
        run=para.add_run(line); run.font.name='Consolas'; run.font.size=Pt(8.2); run.font.color.rgb=RGBColor(35,55,70)
    return para

def callout(title, text, fill='EAF4F5'):
    t=doc.add_table(rows=1, cols=1); t.alignment=WD_TABLE_ALIGNMENT.CENTER
    cell=t.cell(0,0); cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    tcPr=cell._tc.get_or_add_tcPr(); shd=OxmlElement('w:shd'); shd.set(qn('w:fill'),fill); tcPr.append(shd)
    pp=cell.paragraphs[0]; rr=pp.add_run(title+'  '); rr.bold=True; rr.font.color.rgb=RGBColor(8,126,139)
    pp.add_run(text)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)

def add_hyperlink(paragraph, text, url):
    part=paragraph.part
    rid=part.relate_to(url,'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',is_external=True)
    hyperlink=OxmlElement('w:hyperlink'); hyperlink.set(qn('r:id'),rid)
    new_run=OxmlElement('w:r'); rPr=OxmlElement('w:rPr'); color=OxmlElement('w:color'); color.set(qn('w:val'),'087E8B'); rPr.append(color)
    u=OxmlElement('w:u'); u.set(qn('w:val'),'single'); rPr.append(u); new_run.append(rPr)
    txt=OxmlElement('w:t'); txt.text=text; new_run.append(txt); hyperlink.append(new_run); paragraph._p.append(hyperlink)

# Cover/intro
title=doc.add_paragraph(style='Normal')
title.paragraph_format.space_after=Pt(8)
title_run=title.add_run('CKW Tarifdaten in Home Assistant')
title_run.font.name='Aptos Display'; title_run.font.size=Pt(27); title_run.font.bold=True; title_run.font.color.rgb=RGBColor(23,50,77)
p('Schritt für Schritt: API einrichten, Preise prüfen, im Dashboard anzeigen und für Automationen nutzen','Subtitle')
p('Diese Anleitung baut auf der bereits eingerichteten CKW-Abfrage auf. Sie zeigt, wo die YAML-Konfiguration hingehört und wie aus der Preisliste eine übersichtliche Tabelle sowie ein Sensor für Automationen werden.')
callout('Wichtig zur Datenmenge','CKW liefert Viertelstundenwerte. Ein kompletter Tag umfasst 96 Werte; heute und morgen zusammen ergeben 192. In der Attributansicht sieht man zunächst nur den Anfang der Liste.','EAF4F5')
doc.add_heading('Überblick', level=1)
for x in ['1. CKW-API in configuration.yaml einrichten','2. Daten und morgige Zeitstempel kontrollieren','3. Heutige und morgige Preise nebeneinander anzeigen','4. Sensor für den aktuell gültigen Preis anlegen','5. Automation bei weniger als 20 Rp./kWh erstellen','6. Fehler gezielt beheben']:
    bullet(x)
callout('Voraussetzung','Der CKW-REST-Sensor ist bereits eingerichtet und heisst in Home Assistant sensor.ckw_tarifdaten. Falls die Entitäts-ID bei dir anders lautet, ersetze sie in den Beispielen.','FFF5DF')

doc.add_page_break()
doc.add_heading('1. CKW-API in Home Assistant einrichten', level=1)
reset_steps()
p('Die CKW-API stellt Viertelstundenwerte als JSON bereit. In Home Assistant liest die eingebaute RESTful-Integration diese Daten ein. Die Konfiguration gehört in die Datei configuration.yaml, nicht in eine Dashboard-Karte.')
numbered('Öffne in Home Assistant deinen Datei-Editor, zum Beispiel File editor oder Studio Code Server.')
numbered('Öffne configuration.yaml und suche den vorhandenen Abschnitt rest:. Wenn der Sensor bereits funktioniert, ändere nicht den ganzen Abschnitt, sondern vergleiche ihn mit diesem Beispiel.')
code('''rest:
  - resource: https://e-ckw-public-data.de-c1.eu1.cloudhub.io/api/v1/netzinformationen/energie/dynamische-preise
    scan_interval: 21600
    params:
      tariff_name: home_dynamic
      tariff_type: integrated
      start_timestamp: "{{ today_at('00:00').isoformat() }}"
      end_timestamp: "{{ (today_at('00:00') + timedelta(days=2)).isoformat() }}"
    sensor:
      - name: "CKW Tarifdaten"
        unique_id: ckw_tarifdaten
        value_template: "OK"
        json_attributes:
          - publication_timestamp
          - prices''')
numbered('Speichere die Datei. Prüfe in Home Assistant die YAML-Konfiguration (Einstellungen → System → Reparaturen bzw. YAML-Konfiguration prüfen, je nach Version) und starte Home Assistant neu, falls erforderlich.')
numbered('Warte auf die nächste Abfrage oder aktualisiere den Sensor einmal manuell unter Entwicklerwerkzeuge → Aktionen mit der Aktion homeassistant.update_entity und Ziel sensor.ckw_tarifdaten.')
callout('Zeitraum','Die Parameter fragen ab heute 00:00 Uhr bis übermorgen 00:00 Uhr ab, also heute und morgen. Die Zeitstempel sind dynamisch und berücksichtigen die Home-Assistant-Zeitzone. CKW stellt die Folgetagespreise ab etwa 12 Uhr bereit.','EAF4F5')

doc.add_page_break()
doc.add_heading('2. Prüfen, ob morgen enthalten ist', level=1)
reset_steps()
numbered('Öffne Entwicklerwerkzeuge → Zustände.')
numbered('Filtere im Feld Entitäten filtern nach CKW Tarifdaten. Die Browser-Suche ist dafür ungeeignet; sie durchsucht nur sichtbaren Seitentext.')
numbered('Klicke sensor.ckw_tarifdaten an und kontrolliere unter Attribute publication_timestamp und prices.')
numbered('Scrolle im Attribut prices ans Ende. Der letzte start_timestamp sollte das morgige Datum enthalten. Bei zwei vollen Tagen sind es 192 Werte: 96 pro Tag.')
callout('Einordnung','Der Sensorzustand lautet OK. Die eigentlichen Tarifdaten liegen im Attribut prices. Die Zahl 192 bezieht sich auf zwei Tage mit je 96 Viertelstundenwerten.','FFF5DF')

doc.add_page_break()
doc.add_heading('3. Heutige und morgige Preise nebeneinander anzeigen', level=1)
reset_steps()
p('Für die nebeneinanderliegende Ansicht verwendest du zwei separate Markdown-Karten in einem Abschnitt mit zwei Spalten. Auf schmalen Displays können die Karten automatisch untereinander rutschen.')
numbered('Öffne das Dashboard und wähle Dashboard bearbeiten. Füge einen neuen Abschnitt hinzu und stelle ihn, falls verfügbar, auf zwei Spalten oder doppelte Breite ein.')
numbered('Füge im Abschnitt zwei Manuelle Karten hinzu und platziere eine links und eine rechts. Der folgende Code kommt jeweils vollständig in den YAML-Editor der Karte.')
doc.add_heading('Karte links: heutige Preise', level=2)
code('''type: markdown
content: |
  {% set tag_dt = now() %}
  {% set tag = tag_dt.strftime('%Y-%m-%d') %}
  {% set preise = state_attr('sensor.ckw_tarifdaten', 'prices') or [] %}
  {% set ns = namespace(zeilen=[]) %}
  {% for p in preise %}
    {% if p.start_timestamp[:10] == tag %}
      {% set zeit = p.start_timestamp[11:16] ~ '–' ~ p.end_timestamp[11:16] %}
      {% set rp = (p.integrated[0].value * 100) | round(2) %}
      {% set ns.zeilen = ns.zeilen + ['| ' ~ zeit ~ ' | ' ~ rp|string ~ ' Rp./kWh |'] %}
    {% endif %}
  {% endfor %}
  # CKW Preise heute · {{ tag_dt.strftime('%d.%m.%Y') }}

  | Zeit | Preis |
  |:---|---:|
  {{ ns.zeilen | join('\n  ') }}''')
doc.add_heading('Karte rechts: Preise für morgen', level=2)
code('''type: markdown
content: |
  {% set tag_dt = now() + timedelta(days=1) %}
  {% set tag = tag_dt.strftime('%Y-%m-%d') %}
  {% set preise = state_attr('sensor.ckw_tarifdaten', 'prices') or [] %}
  {% set ns = namespace(zeilen=[]) %}
  {% for p in preise %}
    {% if p.start_timestamp[:10] == tag %}
      {% set zeit = p.start_timestamp[11:16] ~ '–' ~ p.end_timestamp[11:16] %}
      {% set rp = (p.integrated[0].value * 100) | round(2) %}
      {% set ns.zeilen = ns.zeilen + ['| ' ~ zeit ~ ' | ' ~ rp|string ~ ' Rp./kWh |'] %}
    {% endif %}
  {% endfor %}
  # CKW Preise morgen · {{ tag_dt.strftime('%d.%m.%Y') }}

  | Zeit | Preis |
  |:---|---:|
  {{ ns.zeilen | join('\n  ') }}''')
callout('Anzeige','Jede Tabelle zeigt bis zu 96 Viertelstundenwerte in Rp./kWh. Die morgige Tabelle bleibt leer, bis CKW die Folgetagespreise veröffentlicht und Home Assistant sie abgerufen hat.','FFF5DF')
callout('Wenn Karten untereinander stehen','Prüfe, ob beide Karten demselben Abschnitt zugeordnet sind und ob der Abschnitt breit genug ist. Home Assistant kann auf schmalen Ansichten automatisch auf eine Spalte wechseln.','EAF4F5')

doc.add_page_break()
doc.add_heading('4. Aktuellen CKW-Preis als Template-Sensor anlegen', level=1)
reset_steps()
p('Ein numerischer Auslöser kann nicht direkt die verschachtelte Preisliste überwachen. Ein Template-Sensor ermittelt zuerst den Preis des gerade gültigen Viertelstundenintervalls.')
numbered('Öffne Einstellungen → Geräte & Dienste → Helfer → Helfer erstellen → Template → Sensor-Template.')
numbered('Name: CKW aktueller Preis. Füge im Feld Zustand dieses Template ein:')
code('''{% set preise = state_attr('sensor.ckw_tarifdaten', 'prices') or [] %}
{% set jetzt = as_timestamp(now()) %}
{% set aktuell = namespace(wert=none) %}
{% for p in preise %}
  {% set start = as_timestamp(p.start_timestamp, 0) %}
  {% set ende = as_timestamp(p.end_timestamp, 0) %}
  {% if start <= jetzt < ende and p.integrated is defined and p.integrated | count > 0 %}
    {% set aktuell.wert = p.integrated[0].value %}
  {% endif %}
{% endfor %}
{{ aktuell.wert }}''')
numbered('Scrolle im Helfer nach unten. Einheit: CHF/kWh. Geräteklasse leer lassen. Zustandsklasse: Messwert (measurement), falls angeboten. Speichere den Helfer.')
numbered('Gehe zu Entwicklerwerkzeuge → Zustände und suche nach CKW aktueller Preis. Die Entitäts-ID wird automatisch erzeugt; merke dir die tatsächlich angezeigte ID.')
callout('Preiseinheit','0,20 CHF/kWh entspricht 20 Rp./kWh. Der integrierte CKW-Wert enthält nicht zwingend sämtliche fixen Abgaben und den Leistungspreis.','EAF4F5')

doc.add_page_break()
doc.add_heading('5. Automation bei weniger als 20 Rp./kWh', level=1)
reset_steps()
p('Diese Automation wird ausgelöst, wenn der aktuelle Preis unter 0,20 CHF/kWh fällt. Wähle danach die Aktion, die du ausführen möchtest.')
numbered('Öffne Einstellungen → Automationen & Szenen → Automation erstellen → Neue Automation erstellen.')
numbered('Als Auslöser wähle Numerischer Zustand. Entität: dein Sensor CKW aktueller Preis. Feld Unter: 0.20.')
numbered('Füge die gewünschte Aktion hinzu, zum Beispiel ein Gerät einschalten, eine Szene aktivieren oder ein Skript ausführen. Speichere die Automation.')
code('''# Beispiel für den Auslöser in einer YAML-Automation
trigger:
  - platform: numeric_state
    entity_id: sensor.ckw_aktueller_preis
    below: 0.20''')
callout('Auslöseverhalten','Der numerische Zustand löst aus, wenn der Sensor die Schwelle nach unten überschreitet. Wenn du in jedem günstigen Viertelstundenintervall eine Aktion starten willst, ist eine zusätzliche zeitgesteuerte Prüfung mit Preisbedingung sinnvoll.','FFF5DF')

doc.add_heading('6. Fehler gezielt beheben', level=1)
# troubleshooting table
rows=[
('Sensor nicht gefunden','Im Zustände-Tab das linke Feld Entitäten filtern verwenden. Nach CKW Tarifdaten suchen, nicht die Browser-Suche benutzen.'),
('Sensor zeigt OK','Normal: OK ist der Zustand. publication_timestamp und prices sind Attribute des Sensors.'),
('Morgen fehlt in der Tabelle','Im Attribut prices prüfen, ob start_timestamp-Werte mit morgigem Datum enthalten sind. publication_timestamp prüfen und nach 12 Uhr erneut aktualisieren.'),
('Tabelle wird als Text angezeigt','Den vollständigen Kartencode im YAML-Modus einfügen. type: markdown und content: | gehören in den YAML-Editor.'),
('Template-Sensor ist leer','Prüfen, ob sensor.ckw_tarifdaten Preise für den aktuellen Zeitpunkt enthält und ob der richtige Entitätsname verwendet wird.'),
('Automatisierung löst nicht aus','Die tatsächliche Entitäts-ID des Template-Sensors kontrollieren. Prüfen, ob dessen Zustand eine Zahl wie 0.1583 ist und ob die Schwelle als 0.20 eingetragen wurde.'),
]
t=doc.add_table(rows=1, cols=2); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.style='Light Shading Accent 1'
t.rows[0].cells[0].text='Problem'; t.rows[0].cells[1].text='Prüfung / Lösung'
for a,b in rows:
    cells=t.add_row().cells; cells[0].text=a; cells[1].text=b
for row in t.rows:
    for cell in row.cells:
        cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for para in cell.paragraphs:
            para.paragraph_format.space_after=Pt(2)
            for run in para.runs: run.font.size=Pt(8.5)

doc.add_heading('Offizielle Dokumentation', level=1)
p1=doc.add_paragraph('CKW technische Informationen zur API: '); add_hyperlink(p1,'Dynamischer Netztarif – technische Voraussetzungen','https://www.ckw.ch/energie/strom/dynamischer-tarif-fuer-privatkunden-und-unternehmen/dynamischer-tarif-technische-voraussetzungen')
p2=doc.add_paragraph('Home Assistant RESTful-Integration: '); add_hyperlink(p2,'RESTful','https://www.home-assistant.io/integrations/rest/')
p3=doc.add_paragraph('Home Assistant RESTful Sensor: '); add_hyperlink(p3,'RESTful Sensor','https://www.home-assistant.io/integrations/sensor.rest/')

# avoid orphaned headings and configure table headers
for para in doc.paragraphs:
    if para.style.name.startswith('Heading'):
        para.paragraph_format.keep_with_next=True
# file properties
doc.core_properties.title='CKW Tarifdaten in Home Assistant'
doc.core_properties.subject='Schritt-für-Schritt-Anleitung zur CKW-API, Dashboard-Tabelle und Automation'
doc.core_properties.author=''
doc.save(out)
print(out)
